/* app.js - QR Order System (Full Clean Version) */
const APP_KEY = 'qr_order_demo_v1';

/* Sample images (local project images folder recommended) */
const IMG_CAFE_SUADA = "images/cafe-suada.jpg";
const IMG_TRA_DAO = "images/tra-dao.jpg";
const IMG_MY_CAY = "images/my-cay.jpg";
const IMG_BANH_FLAN = "images/banh-flan.jpg";
const IMG_BANH_BONG_LAN = "images/banh-bong-lan.jpg";
const IMG_MATCHA = "images/matcha.jpg";
const IMG_NUOC_CAM = "images/nuoc-cam.jpg";
const IMG_KHOAI_TAY = "images/khoai-tay.jpg";

/* Category definitions */
const CATEGORIES = [
  { id: 'all',     name: 'Tất cả',       icon: '📋' },
  { id: 'cafe',    name: 'Cà phê',       icon: '☕' },
  { id: 'tra',     name: 'Trà trái cây', icon: '🍵' },
  { id: 'trasua',  name: 'Trà sữa',      icon: '🧋' },
  { id: 'nuocep',  name: 'Nước ép',      icon: '🍊' },
  { id: 'banh',    name: 'Bánh ngọt',    icon: '🍰' },
  { id: 'monno',   name: 'Món no',       icon: '🍛' },
  { id: 'snack',   name: 'Ăn vặt',       icon: '🍟' }
];

/* Demo data */
function initDemoData(){  
  localStorage.removeItem(APP_KEY);


  const demo = {
    menu: [
      { id: 101, name: "Cà phê sữa đá", price: 25000, category: "cafe",    desc: "Cà phê chuẩn gu Việt", img: "https://lh6.googleusercontent.com/proxy/LcrQvf5VlPKjyIVgH6UUURhh9HPOorCMbr091cGQwkF78pqw6TtPnLT1zlsPJA87rvAxSrntSrJhT6F2u_O6N3i2pK4y32kEZ7cvDpHA9DwHhvnLNozl_5EPfQzpwpgVHbaMky5_rdUqjAzGmGNY6VYeZDhmFDfDpk8d20z8Q9bX-OYGaTeiXuiaA4M" },
      { id: 102, name: "Trà đào cam sả", price: 32000, category: "tra",    desc: "Thanh mát, mùi đào", img: "https://product.hstatic.net/200000791069/product/lord-50_5221e714bef5444aaab6759e2a219146_master.jpg" },
      { id: 103, name: "Mỳ cay hải sản", price: 45000, category: "monno",  desc: "Cay nồng, ngon tuyệt", img: "https://haisanloccantho.com/wp-content/uploads/2024/11/mi-cay-hai-san.jpg" },
      { id: 104, name: "Bánh flan", price: 22000, category: "banh",        desc: "Mềm mịn béo thơm", img: "https://monngonmoingay.com/wp-content/uploads/2024/08/cach-lam-banh-flan-bang-noi-chien-khong-dau-1-1.jpg" },
      { id: 105, name: "Bông lan phô mai", price: 30000, category: "banh", desc: "Xốp mềm tan", img: "https://www.huongnghiepaau.com/wp-content/uploads/2019/07/banh-bong-lan-pho-mai-dai-loan.jpg" },
      { id: 106, name: "Matcha Latte", price: 35000, category: "trasua",   desc: "Matcha chuẩn Nhật", img: "https://cdn.loveandlemons.com/wp-content/uploads/2023/06/iced-matcha-latte.jpg" },
      { id: 107, name: "Nước ép cam", price: 20000, category: "nuocep",    desc: "Vắt tươi mỗi ngày", img: "https://suckhoedoisong.qltns.mediacdn.vn/324455921873985536/2022/2/19/cach-lam-nuoc-cam-ep-ngon-va-thom-ket-hop-voi-le-va-gung-5-1645248090817401855254.jpg" },
      { id: 108, name: "Khoai tây chiên", price: 18000, category: "snack", desc: "Giòn rụm nóng hổi", img: "https://cdn.tgdd.vn/2021/07/CookProduct/khoai-tay-chien-bao-nhieu-calo-an-khoai-lang-hay-khoai-tay-chien-tot-hon-00-1200x676.jpg" }
    ],
    tables: [1,2,3,4,5,6],
    orders: [],
    nextOrderId: 1
  };

  localStorage.setItem(APP_KEY, JSON.stringify(demo));
}

/* DB functions */
function readData(){ return JSON.parse(localStorage.getItem(APP_KEY) || '{}'); }
function writeData(d){ localStorage.setItem(APP_KEY, JSON.stringify(d)); }
function formatVND(n){ return n.toLocaleString('vi-VN') + ' ₫'; }

/* Cart (sessionStorage) */
function getCart(){ return JSON.parse(sessionStorage.getItem('qr_cart') || '[]'); }
function setCart(c){ sessionStorage.setItem('qr_cart', JSON.stringify(c)); updateBottomCart(); }

/* Category chips */
function renderCategories(){
  const wrap = document.getElementById('cat-row');
  if (!wrap) return;
  wrap.innerHTML = '';

  CATEGORIES.forEach(cat=>{
    const btn = document.createElement('div');
    btn.className = `cat-chip ${cat.id==='all' ? 'active':''}`;
    btn.dataset.cat = cat.id;
    btn.innerHTML = `${cat.icon} ${cat.name}`;
    btn.onclick = ()=> {
      document.querySelectorAll('.cat-chip').forEach(c=>c.classList.remove('active'));
      btn.classList.add('active');
      renderMenuList(cat.id);
    };
    wrap.appendChild(btn);
  });
}

/* Show menu by category */
function renderMenuList(catId='all'){
  const data = readData();
  const wrap = document.getElementById('menu-list');
  if (!wrap) return;

  const filtered = data.menu.filter(m=> catId==='all' ? true : m.category === catId);

  wrap.innerHTML = filtered.map(m=>`
    <div class="menu-card" onclick="openPopup(${m.id})">
      <div class="card-media"><img src="${m.img}"></div>
      <div class="card-body">
        <div class="menu-name">${m.name}</div>
        <div class="menu-desc">${m.desc}</div>
        <div class="menu-price">${formatVND(m.price)}</div>
      </div>
    </div>
  `).join('');
}

/* Popup logic */
let popupState = { id:null, qty:1 };

function openPopup(id){
  const data = readData();
  const m = data.menu.find(x=>x.id===id);
  if (!m) return;

  popupState = { id:m.id, qty:1 };

  document.getElementById("popup-img").src = m.img;
  document.getElementById("popup-title").textContent = m.name;
  document.getElementById("popup-desc").textContent = m.desc;
  document.getElementById("popup-price").textContent = formatVND(m.price);
  document.getElementById("popup-qty").textContent = 1;

  document.getElementById("popup").style.display = "flex";
}
function closePopup(){ document.getElementById("popup").style.display="none"; }

function popupChangeQty(n){
  popupState.qty = Math.max(1, popupState.qty + n);
  document.getElementById("popup-qty").textContent = popupState.qty;
}

function popupAddToCart(){
  const data = readData();
  const m = data.menu.find(x=>x.id===popupState.id);
  if (!m) return;

  let cart = getCart();
  const ex = cart.find(x=>x.menuId===m.id);

  if (ex) ex.qty += popupState.qty;
  else cart.push({ menuId:m.id, name:m.name, price:m.price, qty:popupState.qty, img:m.img });

  setCart(cart);
  closePopup();
}

/* Toast */
function toast(msg){
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(()=>t.classList.add("show"),20);
  setTimeout(()=>{t.classList.remove("show"); setTimeout(()=>t.remove(),300);},1500);
}

/* Bottom cart */
function updateBottomCart(){
  const cart = getCart();
  const b = document.getElementById("bottom-cart");
  if (!b) return;

  const count = cart.reduce((s,i)=>s+i.qty,0);
  const total = cart.reduce((s,i)=>s+i.qty*i.price,0);

  if (count===0){
    b.style.display="none";
  } else {
    document.getElementById("bottom-count").textContent = count;
    document.getElementById("bottom-total").textContent = formatVND(total);
    b.style.display="flex";
  }
}

/* Open cart window */
function openCart(){
  const cart = getCart();
  if (cart.length === 0) return alert("Giỏ hàng trống");

  let html = `<h2>Giỏ hàng</h2>`;
  cart.forEach(it=>{
    html += `<div>${it.name} x${it.qty} — ${formatVND(it.qty*it.price)}</div>`;
  });

  const total = cart.reduce((s,i)=>s + i.qty*i.price,0);

  html += `
    <hr>
    <div><strong>Tổng: ${formatVND(total)}</strong></div>
    <br>
    <button onclick="window.opener.placeOrder(); window.close();" style="padding:8px 12px;">Gửi order</button>
    <button onclick="window.opener.clearCart(); window.close();" style="padding:8px 12px;margin-left:10px;">Xóa giỏ</button>
  `;

  const w = window.open("", "_blank", "width=420,height=680");
  w.document.write(`<body style="font-family:Inter;padding:16px;">${html}</body>`);
}

/* Clear cart */
function clearCart(){
  sessionStorage.removeItem("qr_cart");
  updateBottomCart();
}

/* Place order */
function placeOrder(){
  const cart = getCart();
  if (cart.length===0) return alert("Giỏ hàng trống!");

const params = new URLSearchParams(location.search);
const table = params.get('table') || 1;   // đặt mặc định bàn 1


  if (!table){
    table = prompt("Nhập số bàn:");
    if (!table) return;
  }

  const data = readData();
  const order = {
    id: data.nextOrderId++,
    table,
    items: cart,
    status: "new",
    paid: false,
    createdAt: new Date().toISOString()
  };

  data.orders.push(order);
  writeData(data);
  setCart([]);

  alert("Đặt món thành công! Mã đơn: " + order.id);
}

/* Cancel order */
function cancelOrder(id){
  const data = readData();
  const o = data.orders.find(x=>x.id===id);

  if (!o) return alert("Không tìm thấy đơn");
  if (!confirm("Hủy đơn #" + id + "?")) return;

  o.status = "canceled";
  writeData(data);

  renderCashierPage();
}

/* Kitchen page: render orders and allow status update */
function renderKitchenPage() {
  const data = readData();
  const list = document.getElementById('orders-list');
  if (!list) return;
  if (!data.orders || data.orders.length === 0) {
    list.innerHTML = '<div class="small">Chưa có order</div>'; return;
  }
  const sorted = data.orders.slice().sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt));
  list.innerHTML = sorted.map(o => `
    <div class="order-card">
      <div style="display:flex;justify-content:space-between">
        <div><strong>Đơn #${o.id}</strong> • Bàn ${o.table}</div>
        <div class="small">${new Date(o.createdAt).toLocaleString()}</div>
      </div>
      <div style="margin-top:6px">${o.items.map(it => `<div>${it.name} x${it.qty} — ${formatVND(it.price*it.qty)}</div>`).join('')}</div>
      <div style="margin-top:8px;display:flex;justify-content:space-between;align-items:center">
        <div>${o.status === 'new' ? '<span class="status-new">NEW</span>' : o.status === 'preparing' ? '<span class="status-prep">Preparing</span>' : '<span class="status-done">Done</span>'}</div>
        <div class="actions">
          ${o.status !== 'preparing' ? `<button onclick="updateOrderStatus(${o.id}, 'preparing')">Bắt đầu</button>` : ''}
          ${o.status !== 'done' ? `<button onclick="updateOrderStatus(${o.id}, 'done')">Hoàn thành</button>` : ''}
        </div>
      </div>
    </div>
  `).join('');
}

function updateOrderStatus(orderId, newStatus) {
  const data = readData();
  const o = data.orders.find(x=>x.id===orderId);
  if (!o) return alert('Không tìm thấy đơn');
  o.status = newStatus;
  writeData(data);
  renderKitchenPage();
}


/* Cashier page */
function renderCashierPage(){
  const data = readData();
  const wrap = document.getElementById("cashier-orders");
  if (!wrap) return;

  const orders = data.orders.sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt));

  wrap.innerHTML = orders.map(o=>{
    const total = o.items.reduce((s,it)=>s+it.qty*it.price,0);

    return `
      <div class="order-card">
        <div style="display:flex;justify-content:space-between">
          <div><strong>Đơn #${o.id}</strong> • Bàn ${o.table}</div>
          <div class="small">${new Date(o.createdAt).toLocaleString()}</div>
        </div>

        <div style="margin-top:8px">
          ${o.items.map(it=>`${it.name} x${it.qty}`).join("<br>")}
        </div>

        <div style="margin-top:10px;display:flex;justify-content:space-between">
          <strong>${formatVND(total)}</strong>

          ${o.status!=="canceled" ? `
            ${!o.paid ? `<button onclick="markPaid(${o.id})">Thanh toán</button>` : ""}
            <button onclick="cancelOrder(${o.id})" style="background:#ffcccc">Hủy</button>
          ` : `<span class="status-cancel">Canceled</span>`}
        </div>
      </div>
    `;
  }).join("");
}

/* Pay */
function markPaid(id){
  const data = readData();
  const o = data.orders.find(x=>x.id===id);

  if (!o) return;
  o.paid = true;
  writeData(data);
  renderCashierPage();
}

/* Entry */
document.addEventListener("DOMContentLoaded", ()=>{
  initDemoData();

  if (document.getElementById("menu-list")){
    renderCategories();
    renderMenuList("all");
    updateBottomCart();
  }

  if (document.getElementById("orders-list")) renderKitchenPage();
  if (document.getElementById("cashier-orders")) renderCashierPage();
});
// =========================
//  ADMIN - THÊM MÓN MỚI
// =========================
function adminAddMenu() {
  const name = prompt("Tên món:");
  if (!name) return;

  const price = Number(prompt("Giá tiền:", "30000"));
  if (isNaN(price)) return alert("Giá không hợp lệ!");

  const desc = prompt("Mô tả món:", "");
  const img = prompt("Link ảnh món (URL):", "");

  const data = readData();

  const newId =
    data.menu.length > 0
      ? Math.max(...data.menu.map(m => m.id)) + 1
      : 100;

  data.menu.push({
    id: newId,
    name,
    price,
    desc,
    img,
    category: "other"
  });

  writeData(data);

  alert("Đã thêm món mới thành công!");
  renderAdmin(); // render lại giao diện quản lý
}
function renderAdmin() {
  const data = readData();
  const wrap = document.getElementById("admin-menu");
  if (!wrap) return;

  wrap.innerHTML = data.menu
    .map(
      m => `
      <div class="admin-item">
        <div class="admin-left">
          <div class="admin-name">${m.name}</div>
          <div>Giá: ${formatVND(m.price)}</div>
          <div>${m.desc || ""}</div>
          <div class="admin-status ${m.status === "off" ? "off" : ""}">
            ${m.status === "off" ? "Hết hàng" : "Còn hàng"}
          </div>
        </div>

        <div class="admin-actions">
          <button onclick="adminToggleStatus(${m.id})">Đổi trạng thái</button>
          <button onclick="adminEditMenu(${m.id})">Sửa</button>
          <button onclick="adminDeleteMenu(${m.id})">Xóa</button>
        </div>
      </div>
    `
    )
    .join("");
}
// sửa món 
function adminEditMenu(id) {
  const data = readData();
  const m = data.menu.find(x => x.id === id);
  if (!m) return;

  // Nhập dữ liệu mới
  const name = prompt("Tên món:", m.name);
  if (!name) return;

  const price = Number(prompt("Giá:", m.price));
  if (isNaN(price)) return alert("Giá phải là số!");

  const desc = prompt("Mô tả:", m.desc);
  const img = prompt("Link ảnh:", m.img);

  // Cập nhật
  m.name = name;
  m.price = price;
  m.desc = desc;
  m.img = img;

  writeData(data);
  renderAdmin();
  alert("Đã cập nhật món!");
}
// xóa món
function adminDeleteMenu(id) {
  if (!confirm("Xóa món này?")) return;

  const data = readData();
  data.menu = data.menu.filter(m => m.id !== id);

  writeData(data);
  renderAdmin();
}
// trạng thái còn/ hết hàng
function adminToggleStatus(id) {
  const data = readData();
  const m = data.menu.find(x => x.id === id);
  if (!m) return;

  m.status = m.status === "on" ? "off" : "on";

  writeData(data);
  renderAdmin();
}
